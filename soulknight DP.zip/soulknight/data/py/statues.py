import string
l = ['Elf','Sorcerer','Priest','Assassin','Knight','Paladin','Engineer','Berserker']

for i in l:
	fung = open(string.lower(i) + '_give.mcfunction','w')
	fung.write(r'give 04bp4 minecraft:bat_spawn_egg{display:{Name:"{\"text\":\"Statue of the ' + i + r'\",\"italic\":\"false\"}"},EntityTag:{Tags:["statue_' + string.lower(i) + r'"]}}')
	#funp = open(string.lower(i) + '_place.mcfunction','w')
	#funp.write('execute positioned as @s anchored feet align xz run summon minecraft:armor_stand ~.5 ~ ~.5 {Tags:["statues_*"],NoGravity:1b,CustomName:"\\\"Statue of the '+i+'\\\"",CustomNameVisible:1b,Invisible:1b}\nexecute positioned as @s run setblock ~ ~ ~ *_glazed_terracotta[facing=*]\nexecute positioned as @s run setblock ~ ~1 ~ barrier\nkill @s[type=bat]')