import os

def mkd(pathname):
	if not os.path.isdir(pathname):
		os.mkdir(pathname)

l = ['1_normal','1_boss','2_normal','2_boss','3_normal','3_boss','3-6']
bl = ['1_boss','2_boss','3_boss']

mkd('functions')
for i in l:
	mkd('functions/' + i)
	anchor = open('functions/' + i + '/anchor.mcfunction','w')
	anchor.write('setblock 0 32 0 honeycomb_block\n')
	if i in bl:
		anchor.write('function generate:route_3r')
	else:
		if not i == '3-6':
			anchor.write('function generate:route_2r')